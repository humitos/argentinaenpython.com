# Este programa saluda y pregunta por mi nombre.
print('¡Hola Mundo!')
print('¿Cómo te llamas?')
miNombre = input()
print('Es un placer conocerte, ' + miNombre)
